echo "# test" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/unitraf/test.git
git push -u origin main

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